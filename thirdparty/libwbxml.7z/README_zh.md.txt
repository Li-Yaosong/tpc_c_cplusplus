# libwbxml三方库说明
## 功能简介
libwbxml库是一个专门用于处理WBXML（Wireless Binary XML）文档的C语言编写的开源库，可以实现wbxml和xml格式之间的相互转换。
## 使用约束
- IDE版本：deveco-studio-5.0.3.404
- SDK版本：ohos_sdk_public 4.0.10.18 (API Version 10 Release)
- 三方库版本：0.11.10

## 集成方式
+ [应用hap包集成](docs/hap_integrate.md)