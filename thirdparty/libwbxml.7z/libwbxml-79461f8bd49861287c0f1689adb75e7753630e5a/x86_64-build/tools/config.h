/*
 * Copyright (C) 2008 Michael Bell <michael.bell@opensync.org>
 */

#ifndef WBXML_TOOLS_CONFIG_H
#define WBXML_TOOLS_CONFIG_H

#define FOUND_POSIX_GETOPT

#endif /* WBXML_TOOLS_CONFIG_H */
