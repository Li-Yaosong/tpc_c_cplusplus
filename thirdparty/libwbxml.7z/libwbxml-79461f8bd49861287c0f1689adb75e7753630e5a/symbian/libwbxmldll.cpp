#include <E32BASE.H>
#include <e32def.h>
#include <e32std.h>

GLDEF_C TInt E32Dll(TDllReason /* aReason */)
{
  return(KErrNone);
}
