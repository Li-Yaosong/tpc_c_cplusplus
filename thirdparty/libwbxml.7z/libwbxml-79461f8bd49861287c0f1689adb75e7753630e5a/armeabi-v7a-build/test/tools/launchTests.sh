#!/bin/sh

# Copyright (C) 2009 Michael Bell <michael.bell@opensync.org>

# setup correct path for binaries if they are not in $PATH
if [ "/home/huangtk/Code/OpenHarmony_master_wy/tpc_c_cplusplus/thirdparty/libwbxml/libwbxml-79461f8bd49861287c0f1689adb75e7753630e5a/armeabi-v7a-build/test/tools" ]
then
	WBXML2XML="/home/huangtk/Code/OpenHarmony_master_wy/tpc_c_cplusplus/thirdparty/libwbxml/libwbxml-79461f8bd49861287c0f1689adb75e7753630e5a/armeabi-v7a-build/test/tools/../../tools/wbxml2xml"
	XML2WBXML="/home/huangtk/Code/OpenHarmony_master_wy/tpc_c_cplusplus/thirdparty/libwbxml/libwbxml-79461f8bd49861287c0f1689adb75e7753630e5a/armeabi-v7a-build/test/tools/../../tools/xml2wbxml"
else
	WBXML2XML=`which wbxml2xml`
	XML2WBXML=`which xml2wbxml`
fi

if [ " /usr/bin/perl" != " " ]
then
	PERL_BIN="/usr/bin/perl"
else
	PERL_BIN=`which perl`
fi

NORMALIZE_SCRIPT="/home/huangtk/Code/OpenHarmony_master_wy/tpc_c_cplusplus/thirdparty/libwbxml/libwbxml-79461f8bd49861287c0f1689adb75e7753630e5a/armeabi-v7a-build/test/tools/normalize_xml.pl"

if [ " /usr/bin/diff" != " " ]
then
	DIFF_BIN="/usr/bin/diff"
else
	DIFF_BIN=`which diff`
fi

if [ ! -x "$WBXML2XML" ]
then
    echo Set WBXML2XML to the binary executable of wbxml2xml tool in order to use that script.
    exit 1
fi

if [ ! -x "$XML2WBXML" ]
then
    echo Set XML2XWBML to the binary executable of xml2wbxml tool in order to use that script.
    exit 1
fi

# if somebody enabled CMAKE_SKIP_RPATH
# then it is necessary to specify the path to the library
# Debian does this by default
if [ "ON" ]
then
	LD_LIBRARY_PATH="/home/huangtk/Code/OpenHarmony_master_wy/tpc_c_cplusplus/thirdparty/libwbxml/libwbxml-79461f8bd49861287c0f1689adb75e7753630e5a/armeabi-v7a-build/test/tools/../../src:$LD_LIBRARY_PATH"
	export LD_LIBRARY_PATH
fi

# Go to test suite directory
if [ " $1" != " " -a -d "$1" ]
then
	TEST_SUITE_DIR="$1"
else
	TEST_SUITE_DIR=`dirname $0`
fi

cd "$TEST_SUITE_DIR" || exit 1
PWD=`pwd`

echo Test suite directory is $PWD

# Create temporary directory
TMP_DIR=`mktemp -d -t LibWBXMLTestSuite.XXX`

# execute only a special test directory
if [ " $2" != " " ]
then
	DIRLIST=`find $PWD/. \( -type d -a -name $2 -a ! -name . -prune \) -print | sort`
	if [ ! "$DIRLIST" ]
	then
		DIRLIST=`find $PWD/. \( -type d -a ! -name "*svn*" -a ! -name . -prune \) -print | sort`
		COUNTER=0
		for ITEM in $DIRLIST
		do
			if [ "$COUNTER" -eq "$2" ]
			then
				RESULT=$ITEM
			fi
			COUNTER=`expr $COUNTER + 1`
		done
		DIRLIST=$RESULT
	fi
else
	DIRLIST=`find $PWD/. \( -type d -a ! -name "*svn*" -a ! -name . -prune \) -print | sort`
fi

# For each directory
RESULT="SUCCEEDED"
for i in $DIRLIST
do
  if [ $i != `pwd` ]; then

  echo ----------------------------
  echo Entering into: `basename $i`
  echo ----------------------------

  # execute only a special test in a directory
  if [ `basename $i` != 'ddf' ]; then
  	TESTLIST=`find $i/. \( -type f -name "*.xml" -a ! -name . -prune \) -print | sort`
  else
  	TESTLIST=`find $i/. \( -type f \( -name "*.ddf" -or -name "*.xml" \) -a ! -name . -prune \) -print | sort`
  fi
  if [ " $3" != " " ]
  then
	COUNTER=0
	for ITEM in $TESTLIST
	do
		COUNTER=`expr $COUNTER + 1`
		if [ "$COUNTER" -eq "$3" ]
		then
			TESTCASE=$ITEM
		fi
	done
	TESTLIST=$TESTCASE
  fi

  # For each directory
  for j in $TESTLIST
  do
    echo . `basename $j`

    OUT_WBXML="$TMP_DIR/`basename $i`/`basename $j .xml`.wbxml"
    OUT_XML="$TMP_DIR/`basename $i`/`basename $j`"
    
    # Create output directory if they don't exist
    if [ ! -d "$TMP_DIR/`basename $i`" ]; then
        mkdir -p "$TMP_DIR/`basename $i`"
    fi

    # XML ==> WBXML
    echo Converting into: $OUT_WBXML
    if [ "$TESTDIR" != "ota" -a "$TESTDIR" != "airsync" ]; then
	# disable string tables if they are not really necessary
	NO_STR_TBL="-n";
    fi
    CMD="$XML2WBXML $NO_STR_TBL -o $OUT_WBXML $j"
    $CMD
    if [ $? != 0 ]; then RESULT="FAILED"; fi

    # WBXML ==> XML
    echo Converting back: $OUT_XML
    TESTDIR=`basename $i`
    if [ "$TESTDIR" = "ota" ];
    then
        PARAMS="-l OTA"
    else if [ "$TESTDIR" = "airsync" ];
    then
        PARAMS="-l AIRSYNC"
    else if [ "$TESTDIR" = "ddf" -a `basename $j` != `basename $j ddf` ];
    then
	# only pure DDF documents need this option
	# embedded DDF documents do not need this option
        PARAMS="-l DMDDF12"
    else
        PARAMS=""
    fi fi fi
    CMD="$WBXML2XML $PARAMS -o $OUT_XML $OUT_WBXML"
    $CMD
    if [ $? != 0 ]; then RESULT="FAILED"; fi

    # compare original and generated XML
    echo -n "Comparing the original and the generated XML ... "
    if [ " $PERL_BIN" = " " -o " $DIFF_BIN" = " " ]
    then
	echo UNSUPPORTED
    else if [ `basename $j` = "syncml-012.xml" -o  `basename $j` = "syncml-013.xml" -o `basename $j` = "activesync-032-formatted-base64.xml" ]
    then
	# SyncML CDATA fix makes comparing sometimes impossible
	echo CDATA_ENCAPSULATION
    else
	$PERL_BIN $NORMALIZE_SCRIPT --delete-attribute xmlns $j $OUT_XML.org
	if [ $? != 0 ]; then echo FAILED; RESULT="FAILED"; continue; fi
	$PERL_BIN $NORMALIZE_SCRIPT --delete-attribute xmlns $OUT_XML $OUT_XML.new
	if [ $? != 0 ]; then echo FAILED; RESULT="FAILED"; continue; fi
	DIFF_RESULT=`$DIFF_BIN -b $OUT_XML.org $OUT_XML.new`
	if [ " $DIFF_RESULT" != " " ];
	then
		echo FAILED
		RESULT="FAILED";
	else
		echo SUCCEEDED
	fi
    fi fi
  done

 fi
done

# Cleanup
if [ "$RESULT" == "SUCCEEDED" ];
then
    rm -rf "$TMP_DIR";
fi

echo ---------------------------
echo \\o/ Finished ! Yeah ! \\o/
echo ---------------------------

echo $RESULT
if [ "$RESULT" != "SUCCEEDED" ];
then
    exit 1;
else
    exit 0;
fi
