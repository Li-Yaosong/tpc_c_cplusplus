[
    {
        "Name": "libwbxml",
        "License": "Apache-2.0",
        "License File": "https://github.com/RoaringBitmap/CRoaring/blob/master/LICENSE",
        "Version Number": "0.11.10",
        "Owner": "wangyang497@h-partners.com",
        "Upstream URL": "https://github.com/libwbxml/libwbxml/archive/refs/tags/libwbxml-0.11.10.tar.gz",
        "Description": "libwbxml library is an open source library written in C specifically for processing WBXML (Wireless Binary XML) documents"
    }
]
